def pow(a,b):
    return a**b