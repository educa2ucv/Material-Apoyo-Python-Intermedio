from setuptools import setup
setup(
    name="paquete",
    version="0.1",
    description="Este es un paquete de ejemplo",
    author="Alexanyer Naranjo",
    author_email="educa2ucv@gmail.com",
    url="https://educa2.net/",
    packages=['Functions'],
    scripts=[]
)